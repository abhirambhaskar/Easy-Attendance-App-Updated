package com.ajstudios.easyattendance;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import co.ceryle.radiorealbutton.RadioRealButtonGroup;

public class MyRadioRealButtonGroup extends RadioRealButtonGroup {

    public MyRadioRealButtonGroup(Context context) {
        super(context);
    }

    public MyRadioRealButtonGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyRadioRealButtonGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Make sure to use the allowed Region.Op parameter
            canvas.clipRect(0, 0, canvas.getWidth(), canvas.getHeight());
        } else {
            // Apply the clipping logic or other necessary changes for below API level 28
            super.dispatchDraw(canvas);
        }
    }
}
