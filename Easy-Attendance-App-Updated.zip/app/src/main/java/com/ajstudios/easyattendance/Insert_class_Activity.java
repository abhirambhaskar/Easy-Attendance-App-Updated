package com.ajstudios.easyattendance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.ajstudios.easyattendance.realm.Class_Names;
import java.util.Objects;
import co.ceryle.radiorealbutton.RadioRealButton;
import io.realm.Realm;
import io.realm.RealmAsyncTask;

public class Insert_class_Activity extends AppCompatActivity {

    Button createButton;
    EditText className;
    EditText subjectName;
    Realm realm;
    RealmAsyncTask transaction;
    private String positionBg = "0";

    private RadioButton[] radioButtons;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_class_);

        Toolbar toolbar = findViewById(R.id.toolbar_insert_class);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        createButton = findViewById(R.id.button_createClass);
        className = findViewById(R.id.className_createClass);
        subjectName = findViewById(R.id.subjectName_createClass);

        Realm.init(this);
        realm = Realm.getDefaultInstance();

        RadioGroup group = findViewById(R.id.group);

        radioButtons = new RadioButton[]{
                findViewById(R.id.button1),
                findViewById(R.id.button2),
                findViewById(R.id.button3),
                findViewById(R.id.button4),
                findViewById(R.id.button5),
                findViewById(R.id.button6)
        };

        group.setOnCheckedChangeListener((group1, checkedId) -> {
            for (int i = 0; i < radioButtons.length; i++) {
                if (radioButtons[i].getId() == checkedId) {
                    zoomInAnimation(radioButtons[i]);
                } else {
                    zoomOutAnimation(radioButtons[i]);
                }
            }

            int index = group1.indexOfChild(group1.findViewById(checkedId));
            positionBg = String.valueOf(index);
        });

        createButton.setOnClickListener(view -> {
            if (isValid()) {
                final ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Creating class..");
                progressDialog.show();

                realm.executeTransactionAsync(realm -> {
                    Class_Names class_name = realm.createObject(Class_Names.class);
                    String id = className.getText().toString() + subjectName.getText().toString();
                    class_name.setId(id);
                    class_name.setName_class(className.getText().toString());
                    class_name.setName_subject(subjectName.getText().toString());
                    class_name.setPosition_bg(positionBg);
                }, () -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Successfully created", Toast.LENGTH_SHORT).show();
                    finish();
                }, error -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error!", Toast.LENGTH_SHORT).show();
                });
            } else {
                Toast.makeText(this, "Fill all details", Toast.LENGTH_SHORT).show();
            }
        });





    }

    private void zoomInAnimation(RadioButton button) {
        ScaleAnimation scale = new ScaleAnimation(1f, 1.5f, 1f, 1.5f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(300);
        scale.setFillAfter(true);
        button.startAnimation(scale);
    }

    private void zoomOutAnimation(RadioButton button) {
        ScaleAnimation scale = new ScaleAnimation(1.5f, 1f, 1.5f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(300);
        scale.setFillAfter(true);
        button.startAnimation(scale);
    }

    private int getDrawableForButton(int buttonId) {
        switch (buttonId) {
            case R.id.button1:
                return R.drawable.asset_bg_paleblue;
            case R.id.button2:
                return R.drawable.asset_bg_green;
            case R.id.button3:
                return R.drawable.asset_bg_yellow;
            case R.id.button4:
                return R.drawable.asset_bg_palegreen;
            case R.id.button5:
                return R.drawable.asset_bg_paleorange;
            case R.id.button6:
                return R.drawable.asset_bg_white;
            default:
                return -1;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the Realm instance when no longer needed
        realm.close();
    }


    public boolean isValid() {
        return !className.getText().toString().isEmpty() && !subjectName.getText().toString().isEmpty();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
